package com.bsr.bsrcoin.History

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bsr.bsrcoin.R
import com.bsr.bsrcoin.databinding.UserAgentBinding

class UserOrAgentChoice : AppCompatActivity()  {
    private lateinit var binding: UserAgentBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_agent)


        binding = UserAgentBinding.inflate(layoutInflater)
        setContentView(binding.root)


    }

    fun onClickUser(view: View){
        val intent = Intent(this, ListOfUserOrAgentActivity::class.java)
        startActivity(intent)
    }



     fun onClickAgent(view: View){
        val intent = Intent(this, ListOfUserOrAgentActivity::class.java)
        startActivity(intent)
    }



}