package com.bsr.bsrcoin.Adapter

import android.content.Context

class UserRecyclerViewAdapter(private val context: Context, private val userDetails: String) {

}