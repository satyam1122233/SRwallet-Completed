package com.bsr.bsrcoin.Models

internal class AddRequestModel(
    val reqid: String,
    val userid: String,
    val amount: String,
    val image: String
)