package com.bsr.bsrcoin.network

data class Insurance(
    val agent_name: String,
    val amount: String,
    val duration: String,
    val type: String
)