package com.bsr.bsrcoin.Notification_notUsed

data class PushNotification(
    val data: NotificationData,
    val to: String
)
