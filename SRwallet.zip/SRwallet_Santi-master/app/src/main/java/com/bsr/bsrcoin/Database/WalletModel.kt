package com.bsr.bsrcoin.Database
/*
*
* This I have made a model class inorder to store the properties of a wallet

 */
class WalletModel( val userId:String,  val coinId:String,  val walletId:String,
                   val walletName:String,  val coin:String) {

}