package com.bsr.bsrcoin.Notification_notUsed

data class NotificationData(
    val sender : String,
    val message : String
)
