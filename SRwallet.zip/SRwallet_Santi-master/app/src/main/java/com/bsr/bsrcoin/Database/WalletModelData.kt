package com.bsr.bsrcoin.Database
/*
*
* Class made inorder to store the array of the Wallet Model that is required while parsing the json
*
*/
class WalletModelData(
    val Wallet: Array<WalletModel>
)