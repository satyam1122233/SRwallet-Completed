package com.bsr.bsrcoin


data class UserDetails(
    val userName: String,
    val userId: String,
    val userEmail: String,
)
