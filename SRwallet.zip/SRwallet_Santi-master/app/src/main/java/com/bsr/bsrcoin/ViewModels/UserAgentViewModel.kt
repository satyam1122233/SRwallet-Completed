package com.bsr.bsrcoin.ViewModels

data class UserAgentViewModel(
    val userOrAgent:String
)

